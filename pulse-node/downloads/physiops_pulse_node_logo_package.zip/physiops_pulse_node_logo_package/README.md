# PhysioPS Pulse Node Logo Package

Pulse Node, Concept E, is the selected master mark for PhysioPS × HumanOS. It expresses a live autonomic signal: a compact node, diagnostic ring, and ECG trace.

## Included assets

- `svg/physiops-pulse-node-primary.svg` — primary production mark on dark rounded container.
- `svg/physiops-pulse-node-mark-only.svg` — transparent mark for dark UI surfaces.
- `svg/physiops-pulse-node-monochrome.svg` — currentColor single-color version.
- `svg/physiops-pulse-node-horizontal-lockup.svg` — PhysioPS wordmark lockup.
- `svg/physiops-pulse-node-animated.svg` — self-contained animated SVG with reduced-motion support.
- `favicons/favicon.svg`, `favicon-16.png`, `favicon-32.png`, and `favicon.ico` — production favicon set.
- `app-icons/app-icon-192.svg`, `app-icon-512.svg`, `app-icon-192.png`, `app-icon-512.png`, and `app-icon-1024.png` — app icon source and raster exports.
- `css/pulse-node-logo.tokens.css` — logo color and motion tokens.
- `react/PhysioPSPulseNodeLogo.tsx` — React component with `primary`, `markOnly`, and `monochrome` variants, using collision-safe SVG IDs.
- `preview/index.html` and `preview/pulse-node-contact-sheet.png` — local preview page and quick visual proof sheet.

## Color law

- Teal-green `#00E5A0` = parasympathetic / RFa / active node.
- Electric blue `#4A9EFF` = sympathetic / LFa / ECG trace energy.
- Violet `#A855F7` = HumanOS AI / ML interpretation.
- Deep navy `#030B14` = clinical command surface.

## Usage rules

- Use Pulse Node as the primary app icon, favicon, loading state, and top-nav product mark.
- Use the horizontal lockup for headers, deck covers, PDF covers, and investor collateral.
- Use the monochrome mark only when color reproduction is constrained.
- Never place the colored mark directly on white. If a light context is unavoidable, place it inside the dark rounded container.
- Do not recolor teal or blue independently. The color science maps to P&S physiology.
- Respect `prefers-reduced-motion` for the animated SVG and CSS token implementation.
